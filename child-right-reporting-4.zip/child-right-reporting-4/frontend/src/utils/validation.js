export function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value || "");
}

export function isNonEmpty(value) {
  return typeof value === "string" && value.trim().length > 0;
}

export function validateReportForm({ category, description }) {
  const errors = {};
  if (!isNonEmpty(category)) errors.category = "Please choose a category.";
  if (!isNonEmpty(description)) errors.description = "Please describe what you observed.";
  return errors;
}

export function validateRegisterForm({ name, email, password }) {
  const errors = {};
  if (!isNonEmpty(name)) errors.name = "Name is required.";
  if (!isValidEmail(email)) errors.email = "Enter a valid email address.";
  if (!password || password.length < 8) errors.password = "Password must be at least 8 characters.";
  return errors;
}
