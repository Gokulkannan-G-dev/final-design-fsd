export function formatDate(value) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString();
}

export function formatDateTime(value) {
  if (!value) return "—";
  return new Date(value).toLocaleString();
}

export function truncate(text, length = 120) {
  if (!text) return "";
  return text.length > length ? `${text.slice(0, length)}…` : text;
}
