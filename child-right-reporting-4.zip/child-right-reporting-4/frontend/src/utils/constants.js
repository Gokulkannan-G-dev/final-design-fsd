export const REPORT_CATEGORIES = [
  "Abuse",
  "Neglect",
  "Child labor",
  "Educational issue",
  "Exploitation",
  "Other"
];

export const CASE_STATUS_OPTIONS = ["Pending", "Under Review", "Escalated", "Resolved", "Closed"];

export const USER_ROLES = {
  REPORTER: "reporter",
  REVIEWER: "reviewer",
  ADMIN: "admin"
};
