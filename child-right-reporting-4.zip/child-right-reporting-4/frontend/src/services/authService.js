import { apiRequest, setToken } from "./api.js";

export async function login(email, password) {
  const data = await apiRequest("/auth/login", { method: "POST", body: { email, password } });
  if (data?.token && !data?.mfaRequired) setToken(data.token);
  return data;
}

export async function register(payload) {
  return apiRequest("/auth/register", { method: "POST", body: payload });
}

export async function forgotPassword(email) {
  return apiRequest("/auth/forgot-password", { method: "POST", body: { email } });
}

export async function verifyAccount(code) {
  return apiRequest("/auth/verify-account", { method: "POST", body: { code } });
}

export async function submitProfessionalVerification(payload) {
  return apiRequest("/auth/professional-verification", { method: "POST", auth: true, body: payload });
}

export function logout() {
  setToken(null);
}

export function getCurrentUser() {
  return apiRequest("/auth/me", { auth: true });
}
