import { apiRequest } from "./api.js";

export function listArticles(filters = {}) {
  const params = new URLSearchParams(Object.entries(filters).filter(([, v]) => v));
  return apiRequest(`/content/articles?${params.toString()}`);
}

export function getArticle(id) {
  return apiRequest(`/content/articles/${id}`);
}

export function createArticle(payload) {
  return apiRequest("/content/articles", { method: "POST", auth: true, body: payload });
}

export function updateArticle(id, payload) {
  return apiRequest(`/content/articles/${id}`, { method: "PATCH", auth: true, body: payload });
}

export function deleteArticle(id) {
  return apiRequest(`/content/articles/${id}`, { method: "DELETE", auth: true });
}
