import { apiRequest } from "./api.js";

export function listResources(filters = {}) {
  const params = new URLSearchParams(Object.entries(filters).filter(([, v]) => v));
  return apiRequest(`/resources?${params.toString()}`);
}

export function getResource(id) {
  return apiRequest(`/resources/${id}`);
}

export function createResource(payload) {
  return apiRequest("/resources", { method: "POST", auth: true, body: payload });
}

export function updateResource(id, payload) {
  return apiRequest(`/resources/${id}`, { method: "PATCH", auth: true, body: payload });
}

export function deleteResource(id) {
  return apiRequest(`/resources/${id}`, { method: "DELETE", auth: true });
}
