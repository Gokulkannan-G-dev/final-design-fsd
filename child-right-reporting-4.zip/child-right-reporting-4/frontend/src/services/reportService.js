import { apiRequest } from "./api.js";

export function submitReport(payload) {
  return apiRequest("/reports", { method: "POST", body: payload });
}

export function uploadReportAttachment(reportId, file) {
  const formData = new FormData();
  formData.append("file", file);
  return apiRequest(`/reports/${reportId}/attachments`, { method: "POST", isFormData: true, body: formData });
}

export function trackReport(refCode) {
  return apiRequest(`/reports/track/${encodeURIComponent(refCode)}`);
}
