import { apiRequest } from "./api.js";

export function listCases(filters = {}) {
  const params = new URLSearchParams(Object.entries(filters).filter(([, v]) => v));
  const qs = params.toString();
  return apiRequest(`/cases${qs ? `?${qs}` : ""}`, { auth: true });
}

export function getCase(caseId) {
  return apiRequest(`/cases/${caseId}`, { auth: true });
}

export function updateCase(caseId, updates) {
  return apiRequest(`/cases/${caseId}`, { method: "PATCH", auth: true, body: updates });
}

export function addInternalNote(caseId, note) {
  return apiRequest(`/cases/${caseId}/notes`, { method: "POST", auth: true, body: { note } });
}

export function escalateCase(caseId, payload) {
  return apiRequest(`/cases/${caseId}/escalate`, { method: "POST", auth: true, body: payload });
}

export function getAuditTrail(caseId) {
  return apiRequest(`/cases/${caseId}/audit-log`, { auth: true });
}
