import { apiRequest } from "./api.js";

export function getDashboardSummary() {
  return apiRequest("/analytics/summary", { auth: true });
}

export function getCaseTrends(range = "30d") {
  return apiRequest(`/analytics/case-trends?range=${range}`, { auth: true });
}
