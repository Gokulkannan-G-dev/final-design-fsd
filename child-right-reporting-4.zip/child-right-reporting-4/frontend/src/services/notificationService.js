import { apiRequest } from "./api.js";

export function listNotifications() {
  return apiRequest("/notifications", { auth: true });
}

export function markNotificationRead(id) {
  return apiRequest(`/notifications/${id}/read`, { method: "PATCH", auth: true });
}
