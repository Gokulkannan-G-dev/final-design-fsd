import { apiRequest } from "./api.js";

export function listCampaigns() {
  return apiRequest("/campaigns");
}

export function createCampaign(payload) {
  return apiRequest("/campaigns", { method: "POST", auth: true, body: payload });
}

export function updateCampaign(id, payload) {
  return apiRequest(`/campaigns/${id}`, { method: "PATCH", auth: true, body: payload });
}

export function deleteCampaign(id) {
  return apiRequest(`/campaigns/${id}`, { method: "DELETE", auth: true });
}
