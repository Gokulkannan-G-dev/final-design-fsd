import { apiRequest } from "./api.js";

export function listEvents() {
  return apiRequest("/events");
}

export function createEvent(payload) {
  return apiRequest("/events", { method: "POST", auth: true, body: payload });
}

export function updateEvent(id, payload) {
  return apiRequest(`/events/${id}`, { method: "PATCH", auth: true, body: payload });
}

export function deleteEvent(id) {
  return apiRequest(`/events/${id}`, { method: "DELETE", auth: true });
}
