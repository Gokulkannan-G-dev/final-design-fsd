import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";
import Loading from "../../components/Loading.jsx";
import { useNotifications } from "../../hooks/useNotifications.js";

export default function Notifications() {
  const { notifications, loading, markRead } = useNotifications();

  return (
    <div>
      <Navbar />
      <div className="main-content" style={{ maxWidth: 560, margin: "0 auto" }}>
        <h1>Notifications</h1>
        {loading ? <Loading /> : notifications.length === 0 ? (
          <p>You're all caught up.</p>
        ) : (
          <ul>
            {notifications.map((n) => (
              <li key={n.id} className="info-card" style={{ marginBottom: 8, opacity: n.read ? 0.6 : 1 }}>
                <p>{n.message}</p>
                {!n.read && (
                  <button className="register-btn" style={{ width: "auto", marginTop: 4 }} onClick={() => markRead(n.id)}>
                    Mark as read
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
      <Footer />
    </div>
  );
}
