import { useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";

export default function Settings() {
  const [language, setLanguage] = useState("en");
  const [emailAlerts, setEmailAlerts] = useState(true);

  return (
    <div>
      <Navbar />
      <div className="main-content" style={{ maxWidth: 480, margin: "0 auto" }}>
        <h1>Settings</h1>
        <div className="info-card">
          <label>Language</label>
          <select value={language} onChange={(e) => setLanguage(e.target.value)}>
            <option value="en">English</option>
            <option value="es">Español</option>
            <option value="fr">Français</option>
            <option value="sw">Kiswahili</option>
          </select>

          <label style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 16 }}>
            <input type="checkbox" checked={emailAlerts} onChange={(e) => setEmailAlerts(e.target.checked)} />
            Email me about status changes on my reports
          </label>
        </div>
      </div>
      <Footer />
    </div>
  );
}
