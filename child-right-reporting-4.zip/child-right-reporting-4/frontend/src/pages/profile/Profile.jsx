import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";
import { useAuth } from "../../hooks/useAuth.js";

export default function Profile() {
  const { user } = useAuth();

  return (
    <div>
      <Navbar />
      <div className="main-content" style={{ maxWidth: 480, margin: "0 auto" }}>
        <h1>Your profile</h1>
        <div className="info-card">
          <p><strong>Name:</strong> {user?.name}</p>
          <p><strong>Email:</strong> {user?.email}</p>
          <p><strong>Role:</strong> {user?.role}</p>
        </div>
      </div>
      <Footer />
    </div>
  );
}
