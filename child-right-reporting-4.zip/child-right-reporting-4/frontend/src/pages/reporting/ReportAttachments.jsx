import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function ReportAttachments() {
  const navigate = useNavigate();
  const routerLocation = useLocation();
  const prior = routerLocation.state || {};
  const [fileName, setFileName] = useState("");
  const [file, setFile] = useState(null);
  const [contact, setContact] = useState("");

  function handleFileChange(e) {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
      setFileName(e.target.files[0].name);
    }
  }

  function handleNext(e) {
    e.preventDefault();
    navigate("/report/review", { state: { ...prior, fileName, file, contact } });
  }

  return (
    <div className="report-container" style={{ padding: 32 }}>
      <div className="report-card">
        <h1>Attachments &amp; contact</h1>

        <form onSubmit={handleNext}>
          <label>Attachments (optional)</label>
          <label className="dropzone" htmlFor="report-file" style={{ display: "block", border: "1.5px dashed var(--color-border)", borderRadius: 8, padding: 16, textAlign: "center", cursor: "pointer", marginBottom: 12 }}>
            <span>\u2B06 </span>
            <span>{fileName || "Click to upload photo or document"}</span>
          </label>
          <input id="report-file" type="file" accept="image/*,.pdf,.doc,.docx" onChange={handleFileChange} style={{ display: "none" }} />

          <label>Contact (optional)</label>
          <input
            type="text"
            placeholder="Email or phone for status updates"
            value={contact}
            onChange={(e) => setContact(e.target.value)}
          />

          <p style={{ fontSize: "0.8rem", color: "var(--color-text-muted)", marginTop: 12 }}>
            We remove identifying file metadata automatically. Contact info is only used to send
            you status updates.
          </p>

          <button className="signin-btn" type="submit">Review report</button>
        </form>
      </div>
    </div>
  );
}
