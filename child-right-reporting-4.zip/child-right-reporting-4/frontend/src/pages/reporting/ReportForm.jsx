import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { REPORT_CATEGORIES } from "../../utils/constants.js";

export default function ReportForm() {
  const navigate = useNavigate();
  const [category, setCategory] = useState(REPORT_CATEGORIES[0]);
  const [description, setDescription] = useState("");

  function handleNext(e) {
    e.preventDefault();
    navigate("/report/location", { state: { category, description } });
  }

  return (
    <div className="report-container" style={{ padding: 32 }}>
      <div className="report-card">
        <h1>What are you reporting?</h1>
        <p className="subtitle">Describe what you observed</p>

        <form onSubmit={handleNext}>
          <label>Category</label>
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {REPORT_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
          </select>

          <label>Description</label>
          <textarea
            rows={6}
            placeholder="Describe what you observed…"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />

          <button className="signin-btn" type="submit">Continue</button>
        </form>
      </div>
    </div>
  );
}
