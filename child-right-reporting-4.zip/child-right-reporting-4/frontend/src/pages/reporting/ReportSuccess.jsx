import { useLocation, useNavigate } from "react-router-dom";

export default function ReportSuccess() {
  const routerLocation = useLocation();
  const navigate = useNavigate();
  const refCode = routerLocation.state?.refCode || "—";

  return (
    <div className="report-container" style={{ padding: 32 }}>
      <div className="report-card confirm-card" style={{ textAlign: "center" }}>
        <h1>Report submitted</h1>
        <p className="subtitle">Thank you for speaking up. Your report has been received.</p>

        <div className="ref-box" style={{ background: "var(--color-primary-tint)", borderRadius: 12, padding: 20, margin: "20px 0" }}>
          <p style={{ fontSize: "0.85rem", color: "var(--color-text-muted)", margin: 0 }}>Your reference code</p>
          <p style={{ fontSize: "1.6rem", fontWeight: 700, color: "var(--color-primary-dark)", margin: "4px 0" }}>{refCode}</p>
          <p style={{ fontSize: "0.75rem", color: "var(--color-text-muted)", margin: 0 }}>
            Save this code to track the status of your report. It does not reveal your identity.
          </p>
        </div>

        <button className="register-btn" onClick={() => navigate("/track-report")}>Track this report</button>
        <button className="anonymous-btn" onClick={() => navigate("/")}>Return to home</button>
      </div>
    </div>
  );
}
