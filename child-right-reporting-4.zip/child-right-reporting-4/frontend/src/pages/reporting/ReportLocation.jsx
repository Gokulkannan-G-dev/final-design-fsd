import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function ReportLocation() {
  const navigate = useNavigate();
  const routerLocation = useLocation();
  const prior = routerLocation.state || {};
  const [location, setLocation] = useState("");

  function handleTagLocation() {
    if (!navigator.geolocation) {
      setLocation("Location not supported on this device");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
      },
      () => setLocation("Unable to fetch location")
    );
  }

  function handleNext(e) {
    e.preventDefault();
    navigate("/report/attachments", { state: { ...prior, location } });
  }

  return (
    <div className="report-container" style={{ padding: 32 }}>
      <div className="report-card">
        <h1>Where did this happen?</h1>
        <p className="subtitle">Optional, but helps route your report correctly</p>

        <form onSubmit={handleNext}>
          <label>Location</label>
          <div className="location-row" onClick={handleTagLocation} style={{ cursor: "pointer", padding: 10, border: "1.5px solid var(--color-border)", borderRadius: 6, marginBottom: 12 }}>
            <span>\uD83D\uDCCD </span>
            <span>{location || "Tap to tag current location"}</span>
          </div>
          <input
            type="text"
            placeholder="Or type a general location (neighborhood, school, town)"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <button className="signin-btn" type="submit">Continue</button>
        </form>
      </div>
    </div>
  );
}
