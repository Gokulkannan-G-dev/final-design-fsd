import { useState } from "react";
import { trackReport } from "../../services/reportService.js";
import StatusBadge from "../../components/StatusBadge.jsx";

export default function TrackReport() {
  const [refCode, setRefCode] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const data = await trackReport(refCode);
      setResult(data?.report || null);
    } catch (err) {
      setError(err?.data?.message || "We couldn't find a report with that reference code.");
      setResult(null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container">
      <div className="login-card">
        <h1>Track your report</h1>
        <form onSubmit={handleSubmit}>
          <label>Reference code</label>
          <input value={refCode} onChange={(e) => setRefCode(e.target.value)} placeholder="CR-1234" required />
          <button className="signin-btn" type="submit" disabled={loading}>
            {loading ? "Checking…" : "Check status"}
          </button>
        </form>

        {error && <p style={{ color: "var(--color-danger)", marginTop: 12 }}>{error}</p>}

        {result && (
          <div style={{ marginTop: 16 }}>
            <p><strong>Status:</strong> <StatusBadge status={result.status} /></p>
            <p><strong>Last updated:</strong> {result.updatedAt}</p>
          </div>
        )}
      </div>
    </div>
  );
}
