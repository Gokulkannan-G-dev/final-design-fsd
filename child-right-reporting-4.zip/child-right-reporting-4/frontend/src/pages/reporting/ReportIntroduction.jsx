import { useNavigate } from "react-router-dom";

export default function ReportIntroduction() {
  const navigate = useNavigate();
  return (
    <div className="container">
      <div className="report-card" style={{ maxWidth: 520, textAlign: "center" }}>
        <h1>Report a concern</h1>
        <p className="subtitle">Your identity stays private. Reports are reviewed by trained caseworkers.</p>
        <ul style={{ textAlign: "left", color: "var(--color-text-muted)" }}>
          <li>You can report anonymously.</li>
          <li>We remove identifying file metadata automatically.</li>
          <li>You'll receive a reference code to track your report.</li>
        </ul>
        <button className="signin-btn" onClick={() => navigate("/report/form")}>Start report</button>
      </div>
    </div>
  );
}
