import { useLocation, useNavigate } from "react-router-dom";
import { useReports } from "../../hooks/useReports.js";
import { uploadReportAttachment } from "../../services/reportService.js";

export default function ReportReview() {
  const routerLocation = useLocation();
  const navigate = useNavigate();
  const data = routerLocation.state || {};
  const { submit, submitting, error } = useReports();

  async function handleSubmit() {
    const result = await submit({
      category: data.category,
      description: data.description,
      location: data.location,
      contact: data.contact,
      isAnonymous: !data.contact
    });

    if (data.file && result?.reportId) {
      await uploadReportAttachment(result.reportId, data.file).catch(() => {});
    }

    navigate("/report/success", { state: { refCode: result?.referenceCode } });
  }

  return (
    <div className="report-container" style={{ padding: 32 }}>
      <div className="report-card">
        <h1>Review before you submit</h1>

        <p><strong>Category:</strong> {data.category}</p>
        <p><strong>Description:</strong> {data.description}</p>
        <p><strong>Location:</strong> {data.location || "Not provided"}</p>
        <p><strong>Attachment:</strong> {data.fileName || "None"}</p>
        <p><strong>Contact:</strong> {data.contact || "Anonymous"}</p>

        {error && <p style={{ color: "var(--color-danger)" }}>{error}</p>}

        <button className="signin-btn" onClick={handleSubmit} disabled={submitting}>
          {submitting ? "Submitting…" : "Submit report"}
        </button>
      </div>
    </div>
  );
}
