import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Sidebar from "../../components/Sidebar.jsx";
import Loading from "../../components/Loading.jsx";
import { listCases } from "../../services/caseService.js";

export default function ReviewerDashboard() {
  const [summary, setSummary] = useState({ pending: 0, underReview: 0, escalated: 0, resolved: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listCases()
      .then((data) => {
        const cases = data?.cases || [];
        setSummary({
          pending: cases.filter((c) => c.status === "Pending").length,
          underReview: cases.filter((c) => c.status === "Under Review").length,
          escalated: cases.filter((c) => c.status === "Escalated").length,
          resolved: cases.filter((c) => c.status === "Resolved").length
        });
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="app-shell">
      <Sidebar role="reviewer" />
      <div className="main-content">
        <h1>Reviewer dashboard</h1>
        {loading ? <Loading /> : (
          <div className="card-grid">
            <div className="info-card"><p className="subtitle">Pending</p><h2>{summary.pending}</h2></div>
            <div className="info-card"><p className="subtitle">Under review</p><h2>{summary.underReview}</h2></div>
            <div className="info-card"><p className="subtitle">Escalated</p><h2>{summary.escalated}</h2></div>
            <div className="info-card"><p className="subtitle">Resolved</p><h2>{summary.resolved}</h2></div>
          </div>
        )}
        <p style={{ marginTop: 24 }}><Link to="/reviewer/queue">Go to case queue →</Link></p>
      </div>
    </div>
  );
}
