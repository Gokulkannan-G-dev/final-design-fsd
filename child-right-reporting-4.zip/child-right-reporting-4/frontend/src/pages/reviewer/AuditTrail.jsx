import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Sidebar from "../../components/Sidebar.jsx";
import Loading from "../../components/Loading.jsx";
import { getAuditTrail } from "../../services/caseService.js";

export default function AuditTrail() {
  const { caseId } = useParams();
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAuditTrail(caseId).then((data) => setEntries(data?.entries || [])).finally(() => setLoading(false));
  }, [caseId]);

  return (
    <div className="app-shell">
      <Sidebar role="reviewer" />
      <div className="main-content">
        <h1>Audit trail</h1>
        {loading ? <Loading /> : entries.length === 0 ? (
          <p>No activity recorded yet for this case.</p>
        ) : (
          <ul>
            {entries.map((entry, i) => (
              <li key={i} style={{ marginBottom: 8 }}>
                <strong>{entry.actor}</strong> {entry.action} — {new Date(entry.timestamp).toLocaleString()}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
