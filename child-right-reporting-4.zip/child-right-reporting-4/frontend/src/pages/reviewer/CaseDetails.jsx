import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import Sidebar from "../../components/Sidebar.jsx";
import StatusBadge from "../../components/StatusBadge.jsx";
import Loading from "../../components/Loading.jsx";
import { getCase, updateCase, addInternalNote, escalateCase } from "../../services/caseService.js";
import { CASE_STATUS_OPTIONS } from "../../utils/constants.js";

export default function CaseDetails() {
  const { caseId } = useParams();
  const [caseItem, setCaseItem] = useState(null);
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [escalationNote, setEscalationNote] = useState("");
  const [showEscalate, setShowEscalate] = useState(false);

  function load() {
    setLoading(true);
    getCase(caseId)
      .then((data) => {
        setCaseItem(data);
        setNotes(data?.notes || "");
        setStatus(data?.status || "Pending");
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => { load(); }, [caseId]);

  async function handleStatusChange(e) {
    const newStatus = e.target.value;
    setStatus(newStatus);
    setSaving(true);
    await updateCase(caseId, { status: newStatus }).catch(() => {});
    setSaving(false);
  }

  async function handleSaveNotes() {
    setSaving(true);
    await addInternalNote(caseId, notes).catch(() => {});
    setSaving(false);
  }

  async function handleEscalate() {
    setSaving(true);
    await escalateCase(caseId, { note: escalationNote }).catch(() => {});
    setShowEscalate(false);
    setSaving(false);
    load();
  }

  if (loading) return <div className="app-shell"><Sidebar role="reviewer" /><Loading /></div>;
  if (!caseItem) return <div className="app-shell"><Sidebar role="reviewer" /><p>Case not found.</p></div>;

  return (
    <div className="app-shell">
      <Sidebar role="reviewer" />
      <div className="main-content">
        <h1>Case {caseItem.refCode}</h1>
        <StatusBadge status={caseItem.status} />

        <div className="info-card" style={{ marginTop: 16 }}>
          <p><strong>Category:</strong> {caseItem.category}</p>
          <p><strong>Location:</strong> {caseItem.location || "Not provided"}</p>
          <p><strong>Contact:</strong> {caseItem.contact || "Anonymous"}</p>
          <p><strong>Description:</strong></p>
          <p>{caseItem.description || "No description provided."}</p>
        </div>

        <div className="info-card" style={{ marginTop: 16 }}>
          <label>Status</label>
          <select value={status} onChange={handleStatusChange}>
            {CASE_STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>

        <div className="info-card" style={{ marginTop: 16 }}>
          <label>Internal notes</label>
          <textarea rows={5} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Add verification notes…" style={{ width: "100%" }} />
          <button className="signin-btn" onClick={handleSaveNotes} disabled={saving}>
            {saving ? "Saving…" : "Save notes"}
          </button>
        </div>

        <div className="info-card" style={{ marginTop: 16 }}>
          <p style={{ fontWeight: 600 }}>Escalation</p>
          {!showEscalate ? (
            <button className="register-btn" onClick={() => setShowEscalate(true)}>Escalate to partner organization</button>
          ) : (
            <>
              <textarea rows={3} placeholder="Note for the receiving organization" value={escalationNote} onChange={(e) => setEscalationNote(e.target.value)} style={{ width: "100%" }} />
              <button className="signin-btn" onClick={handleEscalate} disabled={saving}>Confirm escalation</button>
            </>
          )}
        </div>

        <p style={{ marginTop: 16 }}><Link to={`/reviewer/cases/${caseId}/audit-trail`}>View audit trail →</Link></p>
      </div>
    </div>
  );
}
