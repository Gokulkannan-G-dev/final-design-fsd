import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../../components/Sidebar.jsx";
import StatusBadge from "../../components/StatusBadge.jsx";
import Loading from "../../components/Loading.jsx";
import { listCases } from "../../services/caseService.js";
import { CASE_STATUS_OPTIONS } from "../../utils/constants.js";

export default function CaseQueue() {
  const [cases, setCases] = useState([]);
  const [filter, setFilter] = useState("All");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    listCases()
      .then((data) => setCases(data?.cases || []))
      .catch(() => setCases([]))
      .finally(() => setLoading(false));
  }, []);

  const visible = filter === "All" ? cases : cases.filter((c) => c.status === filter);

  return (
    <div className="app-shell">
      <Sidebar role="reviewer" />
      <div className="main-content">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h1>Case review queue</h1>
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option>All</option>
            {CASE_STATUS_OPTIONS.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>

        {loading ? <Loading /> : visible.length === 0 ? (
          <p>No cases yet. Submitted reports will appear here automatically.</p>
        ) : (
          <table className="review-table" style={{ width: "100%", borderCollapse: "collapse", background: "var(--color-surface)", borderRadius: 12, overflow: "hidden" }}>
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: 10 }}>Reference</th>
                <th style={{ textAlign: "left", padding: 10 }}>Category</th>
                <th style={{ textAlign: "left", padding: 10 }}>Location</th>
                <th style={{ textAlign: "left", padding: 10 }}>Submitted</th>
                <th style={{ textAlign: "left", padding: 10 }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((c) => (
                <tr key={c.id} style={{ cursor: "pointer", borderTop: "1px solid var(--color-border)" }} onClick={() => navigate(`/reviewer/cases/${c.id}`)}>
                  <td style={{ padding: 10 }}>{c.refCode}</td>
                  <td style={{ padding: 10 }}>{c.category}</td>
                  <td style={{ padding: 10 }}>{c.location || "—"}</td>
                  <td style={{ padding: 10 }}>{c.submittedAt}</td>
                  <td style={{ padding: 10 }}><StatusBadge status={c.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
