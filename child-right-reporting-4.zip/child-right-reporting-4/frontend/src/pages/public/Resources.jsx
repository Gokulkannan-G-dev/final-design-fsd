import { useEffect, useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";
import ResourceCard from "../../components/ResourceCard.jsx";
import Loading from "../../components/Loading.jsx";
import { listResources } from "../../services/resourceService.js";

export default function Resources() {
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listResources()
      .then((data) => setResources(data?.resources || []))
      .catch(() => setResources([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <Navbar />
      <div className="main-content">
        <h1>Support resources</h1>
        <p className="subtitle">Helplines, shelters, and services near you</p>
        {loading ? <Loading /> : (
          <div className="card-grid">
            {resources.length === 0 && <p>No resources published yet.</p>}
            {resources.map((r) => <ResourceCard key={r.id} resource={r} />)}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
