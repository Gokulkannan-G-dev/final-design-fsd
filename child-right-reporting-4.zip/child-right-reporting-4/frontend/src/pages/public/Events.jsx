import { useEffect, useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";
import EventCard from "../../components/EventCard.jsx";
import Loading from "../../components/Loading.jsx";
import { listEvents } from "../../services/eventService.js";

export default function Events() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listEvents().then((data) => setEvents(data?.events || [])).catch(() => setEvents([])).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <Navbar />
      <div className="main-content">
        <h1>Upcoming events</h1>
        {loading ? <Loading /> : (
          <div className="card-grid">
            {events.length === 0 && <p>No upcoming events right now.</p>}
            {events.map((e) => <EventCard key={e.id} event={e} />)}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
