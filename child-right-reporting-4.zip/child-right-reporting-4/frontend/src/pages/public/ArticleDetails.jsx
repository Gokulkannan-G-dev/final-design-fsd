import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";
import Loading from "../../components/Loading.jsx";
import { getArticle } from "../../services/contentService.js";

export default function ArticleDetails() {
  const { id } = useParams();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getArticle(id)
      .then((data) => setArticle(data?.article || null))
      .catch((err) => setError(err?.data?.message || "Couldn't load this article."))
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <div>
      <Navbar />
      <div className="main-content" style={{ maxWidth: 720, margin: "0 auto" }}>
        {loading && <Loading />}
        {error && <p className="subtitle">{error}</p>}
        {article && (
          <>
            <h1>{article.title}</h1>
            <p className="subtitle">{article.meta} · {article.region}</p>
            <p>{article.body}</p>
          </>
        )}
      </div>
      <Footer />
    </div>
  );
}
