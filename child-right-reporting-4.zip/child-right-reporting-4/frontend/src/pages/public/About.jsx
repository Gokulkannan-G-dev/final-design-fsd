import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";

export default function About() {
  return (
    <div>
      <Navbar />
      <div className="main-content" style={{ maxWidth: 720, margin: "0 auto" }}>
        <h1>About this platform</h1>
        <p>
          The Child Rights Reporting Platform lets children, caregivers, educators, and community
          members report concerns about a child's safety or rights and connects those reports to
          trained caseworkers and partner organizations for follow-up.
        </p>
        <h2>Our principles</h2>
        <p>
          Every design decision is weighed against the risk of exposing a child or reporter to
          harm. The platform assists triage and routing — it never replaces a trained caseworker's
          judgment.
        </p>
      </div>
      <Footer />
    </div>
  );
}
