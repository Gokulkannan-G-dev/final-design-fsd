import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";

export default function EmergencyHelp() {
  return (
    <div>
      <Navbar />
      <div className="main-content" style={{ maxWidth: 640, margin: "0 auto" }}>
        <h1>If a child is in immediate danger</h1>
        <p>
          If you believe a child is in immediate physical danger, contact your local emergency
          services right away. This platform supports reporting and follow-up, but it is not a
          substitute for emergency response.
        </p>
        <div className="info-card">
          <p style={{ fontWeight: 600 }}>National child helpline</p>
          <p>Available 24/7 — see your local directory for the correct number in your country.</p>
        </div>
      </div>
      <Footer />
    </div>
  );
}
