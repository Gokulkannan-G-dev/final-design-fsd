import { Link } from "react-router-dom";
import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";

export default function Home() {
  return (
    <div>
      <Navbar />
      <div className="container" style={{ minHeight: "60vh" }}>
        <div className="login-card" style={{ maxWidth: 560, textAlign: "center" }}>
          <h1>A safe place to speak up for a child.</h1>
          <p className="subtitle">
            Report a concern about a child's safety or rights, confidentially and at your own pace.
            Every report reaches a trained person, never an automated decision.
          </p>
          <Link to="/report"><button className="primary-btn">Report a concern</button></Link>
          <Link to="/awareness"><button className="register-btn">Learn about child rights</button></Link>
        </div>
      </div>
      <Footer />
    </div>
  );
}
