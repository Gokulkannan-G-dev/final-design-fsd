import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";
import Loading from "../../components/Loading.jsx";
import { getResource } from "../../services/resourceService.js";

export default function ResourceDetails() {
  const { id } = useParams();
  const [resource, setResource] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getResource(id).then((data) => setResource(data?.resource || null)).finally(() => setLoading(false));
  }, [id]);

  return (
    <div>
      <Navbar />
      <div className="main-content" style={{ maxWidth: 720, margin: "0 auto" }}>
        {loading && <Loading />}
        {resource && (
          <>
            <h1>{resource.title}</h1>
            <p className="subtitle">{resource.category} · {resource.region}</p>
            <p>{resource.description}</p>
            {resource.contact && <p><strong>Contact:</strong> {resource.contact}</p>}
          </>
        )}
      </div>
      <Footer />
    </div>
  );
}
