import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";
import ArticleCard from "../../components/ArticleCard.jsx";
import Loading from "../../components/Loading.jsx";
import { listArticles } from "../../services/contentService.js";

const FILTERS = ["All", "Article", "Video", "Infographic"];

const FALLBACK_CONTENT = [
  { id: "1", type: "Article", icon: "\uD83D\uDCC4", title: "Recognizing warning signs of abuse", meta: "5 min read", region: "National" },
  { id: "2", type: "Video", icon: "\u25B6", title: "Know your rights: a guide for children", meta: "3 min video", region: "National" },
  { id: "3", type: "Infographic", icon: "\uD83D\uDDBC", title: "How to file a report, step by step", meta: "Infographic", region: "Regional" },
  { id: "4", type: "Article", icon: "\uD83D\uDCC4", title: "Understanding child labor laws", meta: "7 min read", region: "National" }
];

export default function Awareness() {
  const [filter, setFilter] = useState("All");
  const [articles, setArticles] = useState(FALLBACK_CONTENT);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    listArticles()
      .then((data) => {
        if (data?.articles?.length) setArticles(data.articles);
      })
      .catch(() => {
        // Keep the fallback content if the backend isn't reachable yet.
      })
      .finally(() => setLoading(false));
  }, []);

  const visible = filter === "All" ? articles : articles.filter((a) => a.type === filter);

  return (
    <div>
      <Navbar />
      <div className="main-content">
        <h1>Awareness &amp; education</h1>
        <p className="subtitle">Learn about child rights, warning signs, and how to help</p>

        <div style={{ display: "flex", gap: 8, margin: "16px 0" }}>
          {FILTERS.map((f) => (
            <button
              key={f}
              className={f === filter ? "primary-btn" : "register-btn"}
              style={{ width: "auto", marginTop: 0 }}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>

        {loading ? (
          <Loading />
        ) : (
          <div className="card-grid">
            {visible.map((item) => (
              <ArticleCard key={item.id} article={item} onClick={() => navigate(`/awareness/${item.id}`)} />
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
