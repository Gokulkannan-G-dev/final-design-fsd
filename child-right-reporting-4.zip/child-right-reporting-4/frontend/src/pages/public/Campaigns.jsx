import { useEffect, useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Footer from "../../components/Footer.jsx";
import Loading from "../../components/Loading.jsx";
import { listCampaigns } from "../../services/campaignService.js";

export default function Campaigns() {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listCampaigns().then((data) => setCampaigns(data?.campaigns || [])).catch(() => setCampaigns([])).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <Navbar />
      <div className="main-content">
        <h1>Active campaigns</h1>
        {loading ? <Loading /> : (
          <div className="card-grid">
            {campaigns.length === 0 && <p>No active campaigns right now.</p>}
            {campaigns.map((c) => (
              <div className="info-card" key={c.id}>
                <p style={{ fontWeight: 600 }}>{c.title}</p>
                <p>{c.description}</p>
              </div>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
